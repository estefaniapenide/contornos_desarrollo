/*
 * Cálculo de interés simple = capital * redito * tiempo/100.
 * El capital y el tiempo son >0.
 * El redito puede ser negativo o cero.
 * autor: profesor
 */
package proyecto_interes;
public class InteresTotal {
    protected float capital;
    protected float redito;
    protected int tiempo;
    public InteresTotal(int tiempo, float capital, float redito) {        
        this.capital=capital;
        this.redito=redito;
        this.tiempo=tiempo;
    }

    /**
     * @return the capital
     */
    public float getCapital() {
        return capital;
    }

    /**
     * @return the redito
     */
    public float getRedito() {
        return redito;
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param capital the capital to set
     */
    public void setCapital(float capital) {
        this.capital = capital;
    }

    /**
     * @param redito the redito to set
     */
    public void setRedito(float redito) {
        this.redito = redito;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
    public double CalcularInteres()throws Exception{
        if (getCapital()<=0)
            throw (new Exception ("Error. El capital tiene que ser >=0"));
        if (getTiempo()<=0)
            throw (new Exception ("Error. El interés tiene que ser >=0"));
        double resultado = (double)getCapital()*getRedito()*getTiempo()/100;
 
        return resultado;
    }
}
