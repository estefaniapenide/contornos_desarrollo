package estadisticos;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author profesor
 */
public class EstadisticosTest {

    public EstadisticosTest() {
    }

    /**
     * Test of combinaciones method, of class Estadisticos.
     */
    @Test(expected = Exception.class)
    public void testCombinaciones1() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = -2;
        instance.n = -3;
        double result = instance.combinaciones();
    }

    @Test(expected = Exception.class)
    public void testCombinaciones2() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = -2;
        instance.n = 3;
        double result = instance.combinaciones();
    }

    @Test(expected = Exception.class)
    public void testCombinaciones3() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 2;
        instance.n = -3;
        double result = instance.combinaciones();
    }

    @Test(expected = Exception.class)
    public void testCombinaciones4() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 2;
        instance.n = 3;
        double result = instance.combinaciones();
    }

    @Test
    public void testCombinaciones5() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 3;
        instance.n = 2;
        double result = instance.combinaciones();
        assertEquals(3.0, result, 0);
    }

    @Test
    public void testCombinaciones6() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 1;
        instance.n = 1;
        double result = instance.combinaciones();
        assertEquals(1.0, result, 0);
    }

    @Test
    public void testCombinaciones7() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 0;
        instance.n = 0;
        double result = instance.combinaciones();
        assertEquals(1.0, result, 0);
    }

    /**
     * Test of variaciones method, of class Estadisticos.
     */
    @Test(expected = Exception.class)
    public void testVariaciones1() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = -2;
        instance.n = -3;
        double result = instance.variaciones();
    }

    @Test(expected = Exception.class)
    public void testVariaciones2() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = -2;
        instance.n = 3;
        double result = instance.variaciones();
    }

    @Test(expected = Exception.class)
    public void testVariaciones3() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 2;
        instance.n = -3;
        double result = instance.variaciones();
    }
    @Test(expected = Exception.class)
    public void testVariaciones4() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 2;
        instance.n = 3;
        double result = instance.variaciones();
    }
    @Test
    public void testVariaciones5() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 3;
        instance.n = 2;
        double result = instance.variaciones();
        assertEquals(6.0, result, 0);
    }
    @Test
    public void testVariaciones6() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 1;
        instance.n = 1;
        double result = instance.variaciones();
        assertEquals(1.0, result, 0);
    }@Test
    public void testVariaciones7() throws Exception {
        Estadisticos instance = new Estadisticos();
        instance.m = 0;
        instance.n = 0;
        double result = instance.variaciones();
        assertEquals(1.0, result, 0);
    }
}