/*
 * clase Estadisticos
 */
package estadisticos;

public class Estadisticos {

    public int m;
    public int n;

    /* Cálculo Factorial o permutaciones de x */
    private double factorial(int x){
        double resultado = 1;
        for (int i = 2; i <= x; i++) {
            resultado *= i;
        }
        return resultado;
    }
    /* Cálculo Combinaciones de m elementos tomados de n en n*/
    public double combinaciones() throws Exception{
        if (m<0 || n<0 || m<n) throw (new Exception("Argumentos no válidos"));
        double combi = factorial(m)/(factorial(n)*factorial(m-n));
        return combi;
    }
    /* Cálculo Variaciones de m elementos tomados de n en n */
    public double variaciones() throws Exception {
        if (m<0 || n<0 || m<n) throw (new Exception("Argumentos no válidos"));
        double vari = combinaciones()*factorial(n);
        return vari;
    }
}
