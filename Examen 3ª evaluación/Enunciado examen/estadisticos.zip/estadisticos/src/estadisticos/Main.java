/*
 *  Permite teclar dos valores enteros m y n y Visualiza:
 * -El factorial de m.
 * -El factorial de n.
 * -El número de variaciones sin repetición de m elementos tomados de n en n.
 * -El número de combinaciones sin repetición de m elementos tomados de n en n.
 * -El número de variaciones con repetición de m elementos tomados de n en n.
 * Se utiliza la clase Estadisticos
 * autor: profesor
 */
package estadisticos;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        boolean error;
        int m = 1, n = 1;
        do {
            try {
                error = false;
                System.out.print("\nCALCULOS ESTADÍSTICOS\n");
                System.out.print("Si teclea 0 y 0 finaliza\n");
                System.out.print("Teclee m (> 0): ");
                m = teclado.nextInt();
                System.out.print("Teclee n (> 0 y <= m): ");
                n = teclado.nextInt();
                Estadisticos es = new Estadisticos();
                es.m = m;
                es.n = n;
                System.out.printf("Variaciones(%d,%d) = %f\n", m, n, es.variaciones());
                System.out.printf("Combinaciones(%d,%d) = %f\n", m, n, es.combinaciones());
            } catch (NumberFormatException e) {
                teclado.nextLine(); //para limpiar INTRO del buffer de teclado
                System.out.println("Error en la conversión");
                error = true;
            } catch (InputMismatchException e) {
                teclado.nextLine(); //para limpiar INTRO del buffer de teclado
                System.out.println("Error. El dato tecleado no es válido");
                error = true;
            } catch (Exception e) {
                teclado.nextLine(); //para limpiar INTRO del buffer de teclado
                System.out.println(e.getMessage()); // Muestra el error
                error = true;
            }
        } while (error || (m != 0 && n != 0));
    }
}
